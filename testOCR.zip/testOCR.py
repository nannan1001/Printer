# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 06:09:01 2019

@author: Mars Huang <mars.cc@gmail.com>
@version: v2.0

功用: 測試 Tesseract OCR 多執行緒
基本參數數:

  (1)Tesseract
         tesseract --help-psm
  Page segmentation modes:
  0    Orientation and script detection (OSD) only.
  1    Automatic page segmentation with OSD.
  2    Automatic page segmentation, but no OSD, or OCR. (not implemented)
  3    Fully automatic page segmentation, but no OSD. (Default)
  4    Assume a single column of text of variable sizes.
  5    Assume a single uniform block of vertically aligned text.
  6    Assume a single uniform block of text.
  7    Treat the image as a single text line.
  8    Treat the image as a single word.
  9    Treat the image as a single word in a circle.
 10    Treat the image as a single character.
 11    Sparse text. Find as much text as possible in no particular order.
 12    Sparse text with OSD.
 13    Raw line. Treat the image as a single text line,
       bypassing hacks that are Tesseract-specific.    

 (2)多執行續
 os.environ['OMP_THREAD_LIMIT'] = '1'
 #os.environ['OMP_NUM_THREADS '] = '1'

"""

from   os                 import chdir, makedirs, environ, path
from   concurrent.futures import ProcessPoolExecutor
from   pytesseract        import image_to_string
from   configparser       import ConfigParser
from   itertools          import compress
from   cv2                import imread
from   glob               import glob
from   time               import time
import sys
import ast
import re

###############################################################################
# 定義讀取範圍, 改成讀取 OCR.ini
   
config = ConfigParser()
config.read('OCR.ini', encoding='utf-8')

DIRECTORY = path.dirname(config['OCR.FILE']['ocr_path'])
OUT_DIR   = config['OCR.FILE']['ocr_out']
PREFIX    = config['OCR.PARA']['prefix']
SOURCE_EXT= config['OCR.PARA']['ext']

OCR_DATA  = config['OCR.PARA']['dataset']

WORKERS   = config.getint('OCR.THREAD','WORKERS')
environ['OMP_THREAD_LIMIT'] = config['OCR.THREAD']['OMP_THREAD_LIMIT']
#environ['OMP_NUM_THREADS'] = config['OCR.THREAD']['OMP_NUM_THREADS']

# 動態組合語系
ocrdata   = '+'.join(list(compress(['eng', 'chi_tra', 'chi_sim'], ast.literal_eval(config['OSR.LANG']['lang']))))

# 動態執行程式
Run = list(compress(['Single', 'Multi'], ast.literal_eval(config['OSR.RUN']['thread'])))

###############################################################################
# OCR 辨識副程式
###############################################################################

def ocr(img_path):

    img = imread(img_path)

    text = image_to_string(img, lang=ocrdata, config='--psm 6')
    
    text = re.sub("(?<![ -~])\s+(?![ -~])", "", text)
    
    out_file = re.sub(SOURCE_EXT, ".txt",img_path.split("\\")[-1])
    out_path = OUT_DIR + out_file
    
    fd = open(out_path,"w", encoding='utf-8')
    fd.write("%s" %text)
    
    return out_file

###############################################################################
# 
# 新執行緒函式 (Single 執行單工，Multi 執行多執行緒
#    
###############################################################################

def thread(option='Multi'):
    start = time()
    
    if option == 'Single':        
        for img_path in image_list:
            out_file = ocr(img_path)
            print(img_path.split("\\")[-1],',',out_file,', processed')
           
    else:
        with ProcessPoolExecutor(max_workers = WORKERS) as executor:
            #image_list = glob(DIRECTORY + OCR_DATA + '*' + SOURCE_EXT)
        
            for img_path,out_file in zip(image_list,executor.map(ocr,image_list)):                
                print(img_path.split("\\")[-1],',',out_file,', processed')
   
    end = time()
  
    with open('Time_'+ (str(WORKERS) if Run == ['Multi'] else '1') +'.txt', 'w') as f:
        print(end-start, round((end-start)/len(image_list),2))
        print('Process {:>4} Files, Average {:>4} Sec/Page, Using {:>6} ocrdata'.format(len(image_list), round((end-start)/len(image_list),2), ocrdata), file=f)
       
    return

###############################################################################
# 
# 檢查相關資料夾是否存在
#    
###############################################################################

def checkdir():
    try:
        chdir(DIRECTORY) 
    # 資料集不存在
    except IOError:
        print("資料集不存在。")        
        sys.exit       
    try:
        chdir('../')
        makedirs(OUT_DIR)
    # 檔案已存在的例外處理
    except FileExistsError:
        return

###############################################################################
# 
# 主程式
#    
###############################################################################
if __name__ == '__main__':
    
    checkdir()
    image_list = glob(DIRECTORY + OCR_DATA + '*' + SOURCE_EXT)

    [thread(i) for i in Run]

   
#    text = "今天天氣好 　热，但 是(this is a book)我穿了 3 件衣服。"
#    print(re.sub("(?<![ -~])\s+(?![ -~])", "", text))
