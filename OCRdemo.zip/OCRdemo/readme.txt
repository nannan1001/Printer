运行此代码，需要下载tessract源代码文件：（参照ruichun的配置）
https://sourceforge.net/projects/tess4j/

导入项目后，file->project structure->modules->dependencies->+号->jars or directories
选择刚下载的tess4j->lib下所有的jar文件以及dist目录下唯一的jar文件。

替换demo类开头的文件路径。tessdata即为ocr数据文件，在下载好的tess4j文件里面。