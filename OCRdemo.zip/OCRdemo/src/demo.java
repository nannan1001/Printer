import java.awt.Graphics2D;
import net.sourceforge.tess4j.*;
import java.awt.Image;
import java.awt.image.*;
import java.io.*;

import javax.imageio.ImageIO;


public class demo {
    static String ocr_path = "E:\\gitWhale\\OCRdemo\\testt.png"; // source to be recognized
    static String tessDataPath = "E:\\gitWhale\\Tess4J\\tessdata"; // tessdata
    static String str_path = "E:\\gitWhale\\OCRdemo\\str.txt"; // original text file

    public static String readFileToString(String filepath) throws FileNotFoundException, IOException {
        StringBuilder sb = new StringBuilder();
        String s ="";
        BufferedReader br = new BufferedReader(new FileReader(filepath));

        while( (s = br.readLine()) != null) {
            sb.append(s + "\n");
        }

        br.close();
        String str = sb.toString();
        return str;
    }

    public static int compare(String str, String target) {
        int d[][]; // 矩阵
        int n = str.length();
        int m = target.length();
        int i; // 遍历str的
        int j; // 遍历target的
        char ch1; // str的
        char ch2; // target的
        int temp; // 记录相同字符,在某个矩阵位置值的增量,不是0就是1
        if (n == 0) {
            return m;
        }
        if (m == 0) {
            return n;
        }
        d = new int[n + 1][m + 1];
        for (i = 0; i <= n; i++) { // 初始化第一列
            d[i][0] = i;
        }

        for (j = 0; j <= m; j++) { // 初始化第一行
            d[0][j] = j;
        }

        for (i = 1; i <= n; i++) { // 遍历str
            ch1 = str.charAt(i - 1);
            // 去匹配target
            for (j = 1; j <= m; j++) {
                ch2 = target.charAt(j - 1);
                if (ch1 == ch2 || ch1 == ch2 + 32 || ch1 + 32 == ch2) {
                    temp = 0;
                } else {
                    temp = 1;
                }
                // 左边+1,上边+1, 左上角+temp取最小
                d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + temp);
            }
        }
        return d[n][m];
    }

    public static int min(int one, int two, int three) {
        return (one = one < two ? one : two) < three ? one : three;
    }

        /**
         * 获取两字符串的相似度
         */
        public static float percentage(String str, String target) {
            // 去除空白字符、换行、标点符号
            String regex = "[\\pP\\p{Punct}\\s]";
            return 1 - (float) compare(str.replaceAll(regex, ""), target.replaceAll(regex, ""))
                    / Math.max(str.length(), target.length());
        }



    public static void processImg(BufferedImage ipimage,
               float scaleFactor,
               float offset)
            throws IOException, TesseractException
    {
        // Making an empty image buffer 
        // to store image later 
        // ipimage is an image buffer 
        // of input image 
        BufferedImage opimage
                = new BufferedImage(1050,
                1024,
                ipimage.getType());

        // creating a 2D platform 
        // on the buffer image 
        // for drawing the new image 
        Graphics2D graphic
                = opimage.createGraphics();

        // drawing new image starting from 0 0 
        // of size 1050 x 1024 (zoomed images) 
        // null is the ImageObserver class object 
        graphic.drawImage(ipimage, 0, 0,
                1050, 1024, null);
        graphic.dispose();

        // rescale OP object 
        // for gray scaling images 
        RescaleOp rescale
                = new RescaleOp(scaleFactor, offset, null);

        // performing scaling 
        // and writing on a .png file 
        BufferedImage fopimage
                = rescale.filter(opimage, null);
        ImageIO
                .write(fopimage,
                        ".jpg",
                        new File("pro.jpg"));

        // Instantiating the Tesseract class 
        // which is used to perform OCR 
        Tesseract it = new Tesseract();

        it.setDatapath(tessDataPath);

        // doing OCR on the image 
        // and storing result in string str 
        String str = it.doOCR(fopimage);
        System.out.println(str);


        String ori_str = readFileToString(str_path);
        System.out.println(ori_str);
        System.out.print("Accuracy:");
        System.out.print(percentage(str,ori_str)*100);
        System.out.println("%");
    }

    public static void main(String args[]) throws Exception
    {
        File f
                = new File(
                ocr_path);

        BufferedImage ipimage = ImageIO.read(f);

        // getting RGB content of the whole image file 
        double d
                = ipimage
                .getRGB(ipimage.getTileWidth() / 2,
                        ipimage.getTileHeight() / 2);

        // comparing the values 
        // and setting new scaling values 
        // that are later on used by RescaleOP 
        if (d >= -1.4211511E7 && d < -7254228) {
            processImg(ipimage, 3f, -10f);
        }
        else if (d >= -7254228 && d < -2171170) {
            processImg(ipimage, 1.455f, -47f);
        }
        else if (d >= -2171170 && d < -1907998) {
            processImg(ipimage, 1.35f, -10f);
        }
        else if (d >= -1907998 && d < -257) {
            processImg(ipimage, 1.19f, 0.5f);
        }
        else if (d >= -257 && d < -1) {
            processImg(ipimage, 1f, 0.5f);
        }
        else if (d >= -1 && d < 2) {
            processImg(ipimage, 1f, 0.35f);
        }
    }
} 